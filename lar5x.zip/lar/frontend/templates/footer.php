<?php

/**
 * @author Jackie Do
 * @copyright 2013
 */

echo '            </div><!-- End Main -->
            <div class="clearfix"></div>
        </div><!-- End Content -->
        <div id="bottom">
            Copyright &copy; 20113 by PHPCB78 Việt Chuyên
        </div><!-- End Bottom -->
    </div><!-- End Layout -->

</body>
</html>';

?>