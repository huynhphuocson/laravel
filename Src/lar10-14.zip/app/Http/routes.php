<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('qho_login', ['as' => 'getLogin', 'uses' => 'LoginController@getLogin']);
Route::post('qho_login', ['as' => 'postLogin', 'uses' => 'LoginController@postLogin']);
Route::get('logout', ['as' => 'getLogout', 'uses' => 'LoginController@getLogout']);

Route::group(['middleware' => 'auth'], function () {
    Route::group(['prefix' => 'qho_admin'],function() {
    	Route::get('/',function () {
    		return view('admin.dashboard.main');
    	});
    	Route::group(['prefix' => 'category'],function () {
    		Route::get('add',['as' => 'getAdd', 'uses' => 'CateController@getAdd']);
    	});
    	Route::group(['prefix' => 'user'],function () {

    	});
    	Route::group(['prefix' => 'news'],function () {

    	});
    });
});