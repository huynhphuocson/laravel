<?php $__env->startSection('title','Tranh Chính'); ?>
<?php $__env->startSection('content'); ?>
<table class="function_table" style="margin: 0px auto;">
	<tr>
		<td class="function_item user_add"><a href="<?php echo route('getUserAdd'); ?>">Thêm user</a></td>
		<td class="function_item user_list"><a href="<?php echo route('getUserList'); ?>">Quản lý user</a></td>
		<td rowspan="3" class="statistics_panel">
			<h3>Thống kê:</h3>
			<ul>
				<li>Tổng số user: <?php echo $stas_user; ?></li>
				<li>Tổng số danh mục: <?php echo $stas_cate; ?></li>
				<li>Tổng số tin: <?php echo $stas_news; ?></li>
			</ul>
		</td>
	</tr>
	<tr>
		<td class="function_item cate_add"><a href="<?php echo route('getCateAdd'); ?>">Thêm danh mục</a></td>
		<td class="function_item cate_list"><a href="<?php echo route('getCateList'); ?>">Quản lý danh mục</a></td>
	</tr>
	<tr>
		<td class="function_item news_add"><a href="<?php echo route('getNewsAdd'); ?>">Thêm tin</a></td>
		<td class="function_item news_list"><a href="<?php echo route('getNewsList'); ?>">Quản lý tin</a></td>
	</tr>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>