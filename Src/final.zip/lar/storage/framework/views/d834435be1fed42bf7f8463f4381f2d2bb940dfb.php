<?php $__env->startSection('title','Sửa Danh Mục'); ?>
<?php $__env->startSection('content'); ?>
<form action="" method="POST" style="width: 650px;">
	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	<fieldset>
		<legend>Thông Tin Danh Mục</legend>
		<span class="form_label">Danh mục cha:</span>
		<span class="form_item">
			<select name="sltCate" class="select">
				<option value="0">--- ROOT ---</option>
				<?php menuMulti ($parent,0,$str="---|",$data["parent_id"]) ?>
			</select>
		</span><br />
		<span class="form_label">Tên danh mục:</span>
		<span class="form_item">
			<input type="text" name="txtCateName" class="textbox" value="<?php echo old('txtCateName',isset($data["name"]) ? $data["name"] : null); ?>" />
		</span><br />
		<span class="form_label"></span>
		<span class="form_item">
			<input type="submit" name="btnCateEdit" value="Sửa danh mục" class="button" />
		</span>
	</fieldset>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>