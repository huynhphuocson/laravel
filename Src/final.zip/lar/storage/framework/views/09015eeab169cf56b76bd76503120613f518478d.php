<?php $__env->startSection('title','Trang Chủ'); ?>
<?php $__env->startSection('content'); ?>
<?php foreach($data as $item): ?>
<div class="news">
	<h1><?php echo $item["title"]; ?></h1>
	<img src="<?php echo asset('public/uploads/news/'.$item["image"]); ?>" class="thumbs" />
	<h3>Thể Loại : <?php echo $item["cate"]["name"]; ?></h3>
	<p><?php echo $item["intro"]; ?></p>
	<a href="<?php echo url('chi-tiet-tin/'.$item["id"].'/'.$item["alias"].'.html'); ?>" class="readmore">Đọc thêm</a>
	<div class="clearfix"></div>
</div>
<?php endforeach; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>