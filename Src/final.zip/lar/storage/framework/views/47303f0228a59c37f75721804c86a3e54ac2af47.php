<?php $__env->startSection('title','Thêm Thành Viên'); ?>
<?php $__env->startSection('content'); ?>
<form action="" method="POST" style="width: 650px;">
	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	<fieldset>
		<legend>Thông Tin User</legend>
		<span class="form_label">Username:</span>
		<span class="form_item">
			<input type="text" name="txtUser" class="textbox" value="<?php echo old('txtUser'); ?>" />
		</span><br />
		<span class="form_label">Password:</span>
		<span class="form_item">
			<input type="password" name="txtPass" class="textbox" />
		</span><br />
		<span class="form_label">Confirm password:</span>
		<span class="form_item">
			<input type="password" name="txtRepass" class="textbox" />
		</span><br />
		<span class="form_label">Level:</span>
		<span class="form_item">
			<input type="radio" name="rdoLevel" value="1" checked="checked"
			<?php if(old('rdoLevel') == 1): ?>
				checked
			<?php endif; ?>
			 /> Admin 
			<input type="radio" name="rdoLevel" value="2" 
			<?php if(old('rdoLevel') == 2): ?>
				checked
			<?php endif; ?>
			/> Member
		</span><br />
		<span class="form_label"></span>
		<span class="form_item">
			<input type="submit" name="btnUserAdd" value="Thêm User" class="button" />
		</span>
	</fieldset>
</form>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>