﻿
<?php $__env->startSection('title','Thể Loại Tin'); ?>
<?php $__env->startSection('content'); ?>
<h1 style="margin-bottom:10px;color:red">Thể Loại : <?php echo $cate["name"]; ?></h1>
<?php foreach($news as $item): ?>
<div class="news">
	<h1><?php echo $item["title"]; ?></h1>
	<img src="<?php echo asset('public/uploads/news/'.$item["image"]); ?>" class="thumbs" />
	<p><?php echo $item["intro"]; ?></p>
	<a href="<?php echo url('chi-tiet-tin/'.$item["id"].'/'.$item["alias"].'.html'); ?>" class="readmore">Đọc thêm</a>
	<div class="clearfix"></div>
</div>
<?php endforeach; ?>
<?php $__env->stopSection(); ?>     

<?php echo $__env->make('user.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>