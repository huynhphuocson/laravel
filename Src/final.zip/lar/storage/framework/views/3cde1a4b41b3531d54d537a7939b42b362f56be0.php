<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="QuocTuan.Info" />
    <link rel="stylesheet" href="<?php echo asset('public/qt64_admin/templates/css/style.css'); ?>" />
	<title>Admin Area :: <?php echo $__env->yieldContent('title'); ?></title>
	<script type="text/javascript" src="<?php echo asset('public/qt64_admin/templates/js/plugin/ckeditor/ckeditor.js'); ?>"></script>
</head>

<body>
<div id="layout">
    <div id="top">
        Admin Area :: Trang chính
    </div>
	<div id="menu">
		<table width="100%">
			<tr>
				<td>
					<a href="<?php echo url("/qho_admin"); ?>">Trang chính</a> | <a href="<?php echo route('getUserList'); ?>">Quản lý user</a> | <a href="<?php echo route('getCateList'); ?>">Quản lý danh mục</a> | <a href="<?php echo route('getNewsList'); ?>">Quản lý tin</a>
				</td>
				<td align="right">
					Xin chào <?php echo Auth::user()->username; ?> | <a href="<?php echo url('logout'); ?>">Logout</a>
				</td>
			</tr>
		</table>
	</div>
    <div id="main">
    	<?php echo $__env->make('admin.blocks.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    	<?php echo $__env->make('admin.blocks.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php echo $__env->yieldContent('content'); ?>    
	</div>
    <div id="bottom">
        Copyright © 2016 by QuocTuan.Info & QHOnline.Edu.Vn 
    </div>
</div>
<script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<script src="<?php echo asset('public/qt64_admin/templates/js/myscript.js'); ?>"></script>
</body>
</html>