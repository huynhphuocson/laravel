<?php $__env->startSection('title','Tin Tức'); ?>
<?php $__env->startSection('content'); ?>
<table class="list_table">
	<tr class="list_heading">
		<td class="id_col">STT</td>
		<td>Tiêu Đề</td>
		<td>Tác Giả</td>
		<td>Thời Gian</td>
		<td class="action_col">Quản lý?</td>
	</tr>
    <?php $stt = 0; ?>
    <?php foreach($news as $item): ?>
    <?php $stt++; ?>
	<tr class="list_data">
        <td class="aligncenter"><?php echo $stt; ?></td>
        <td class="list_td aligncenter"><?php echo $item["title"]; ?></td>
        <td class="list_td aligncenter"><?php echo $item["author"]; ?></td>
		<td class="list_td aligncenter">
		<?php /* http://www.tisuchi.com/php-date-time-customization-carbon/ */ ?>
		<?php \Carbon\Carbon::setLocale('vi') ?>
		<?php echo \Carbon\Carbon::createFromTimeStamp(strtotime($item["created_at"]))->diffForHumans(); ?>

		</td>
        <td class="list_td aligncenter">
            <a href="<?php echo route('getNewsEdit',['id'=>$item["id"]]); ?>"><img src="<?php echo asset('public/qt64_admin/templates/images/edit.png'); ?>" /></a>&nbsp;&nbsp;&nbsp;
            <a href="<?php echo route('getNewsDel',['id'=>$item["id"]]); ?>" onclick="return xacnhanxoa('Bạn Có Chắc Muốn Xóa Tin Tức Này')"><img src="<?php echo asset('public/qt64_admin/templates/images/delete.png'); ?>" /></a>
        </td>
    </tr>
	<?php endforeach; ?>
</table>
<?php $__env->stopSection(); ?>
	
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>