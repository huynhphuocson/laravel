﻿
<?php $__env->startSection('title','Chi Tiết Tin'); ?>
<?php $__env->startSection('content'); ?>
<h1 id="title_detail">Mở cửa ô tô gây tai nạn chết người</h1>

<img src="<?php echo asset('public/uploads/news/'.$data["image"]); ?>" class="thumbs_detail" />
<p>
    <i><b>Danh mục</b>: <a href=""><?php echo $data["cate"]["name"]; ?></a><br />
    <b>Nguồn</b>: <?php echo $data["author"]; ?><br />
    <b>Viết bởi</b>: <?php echo $data["author"]; ?><br />
    <b>Ngày viết</b>: <?php echo $data["created_at"]; ?></i>
</p>
<p>
    <?php echo $data["intro"]; ?>                    
</p>
<p>
    <?php echo $data["full"]; ?>                    
</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>