<?php $__env->startSection('title','Danh Mục'); ?>
<?php $__env->startSection('content'); ?>
<table class="list_table">
    <tr class="list_heading">
        <td>Danh Mục</td>
        <td class="action_col">Quản lý?</td>
    </tr>
    <?php listCate ($data) ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>