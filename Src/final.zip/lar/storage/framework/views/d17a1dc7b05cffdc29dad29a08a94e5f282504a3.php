<?php $__env->startSection('title','Thêm Thành Viên'); ?>
<?php $__env->startSection('content'); ?>
<table class="list_table">
	<tr class="list_heading">
		<td class="id_col">STT</td>
		<td>Username</td>
		<td>Level</td>
		<td class="action_col">Quản lý?</td>
	</tr>
    <?php $i = 0 ?>
    <?php foreach($data as $item): ?>
    <?php $i++; ?>
	<tr class="list_data">
        <td class="aligncenter"><?php echo $i; ?></td>
        <td class="list_td aligncenter"><?php echo $item["username"]; ?></td>
        <td class="list_td aligncenter">
            <?php if($item["id"] == 1): ?>
                <span style="color: red; font-weight: bold;">Super Admin</span>
            <?php elseif($item["level"] == 1): ?>
                <span style="color: blue; font-weight: bold;">Admin</span>
            <?php else: ?>
                <span style="color: black;">Member</span>
            <?php endif; ?>
        </td>
        <td class="list_td aligncenter">
            <a href="<?php echo route('getUserEdit', ['id' => $item["id"]]); ?>"><img src="<?php echo asset('public/qt64_admin/templates/images/edit.png'); ?>" /></a>&nbsp;&nbsp;&nbsp;
            <a href="<?php echo route('getUserDel', ['id' => $item["id"]]); ?>" onclick="return xacnhanxoa('Bạn Có Chắc Muốn Xóa Danh Mục Này')"><img src="<?php echo asset('public/qt64_admin/templates/images/delete.png'); ?>" /></a>
        </td>
    </tr>
    <?php endforeach; ?>
	
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>