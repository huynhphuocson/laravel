﻿@extends('user.master')
@section('title','Chi Tiết Tin')
@section('content')
<h1 id="title_detail">Mở cửa ô tô gây tai nạn chết người</h1>

<img src="{!! asset('public/uploads/news/'.$data["image"]) !!}" class="thumbs_detail" />
<p>
    <i><b>Danh mục</b>: <a href="">{!! $data["cate"]["name"] !!}</a><br />
    <b>Nguồn</b>: {!! $data["author"] !!}<br />
    <b>Viết bởi</b>: {!! $data["author"] !!}<br />
    <b>Ngày viết</b>: {!! $data["created_at"] !!}</i>
</p>
<p>
    {!! $data["intro"] !!}                    
</p>
<p>
    {!! $data["full"] !!}                    
</p>
@endsection