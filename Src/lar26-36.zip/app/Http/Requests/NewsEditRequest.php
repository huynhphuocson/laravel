<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

class NewsEditRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'sltCate'   => 'required',
            'txtTitle'  => 'required',
            'txtAuthor' => 'required',
            'txtIntro'  => 'required',
            'txtFull'   => 'required',
            'newsImg'   => 'image|mimes:png,jpg,jpeg,bmp',
        ];
    }

    public function messages () 
    {
        return [
            'sltCate.required'   => 'Vui lòng chọn danh mục',
            'txtTitle.required'  => 'Vui lòng chọn tiêu đề',
            'txtAuthor.required' =>  'Vui lòng nhập tác giả',
            'txtIntro.required'  => 'Vui lòng nhập tóm tắt tin',
            'txtFull.required'   => 'Vui lòng nhập nội dung tin',
            'newsImg.image'      => 'Đây phải là định dạng hình',
            'newsImg.mimes'      => 'Hình của bạn phải là 1 trong các định dạng sau : png,jpg,jpeg,bmp'
        ];
    }
}
